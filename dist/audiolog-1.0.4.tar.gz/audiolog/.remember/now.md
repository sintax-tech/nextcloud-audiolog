
## 10:57 | main
audiolog v1.0.3 lançado (range 28–35, 4 commits: OC.Notification→OCP.Toast, OC::$server, scripts); tarball assinado & coord-aprovado; falta upload apps.nextcloud.com
## 11:31 | main
AudioLog 1.0.3 aprovado (DI fixes, OC.Notification→OCP.Toast, NC 28–35) + docs (CHANGELOG.md 1.0.0–1.0.3, README.md pt-BR/correções, PUBLISHING.md reescrita), merged main (cece721); falta upload apps.nextcloud.com.